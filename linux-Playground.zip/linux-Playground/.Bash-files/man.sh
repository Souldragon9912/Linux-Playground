#!/bin/bash


spinner() {
    local pid=$!
    local spin='|/-\'
    local i=0

    while kill -0 "$pid" 2>/dev/null; do
        i=$(( (i+1) %4 ))
        printf "\r[%c] Loading..." "${spin:$i:1}"
        sleep 1
    done
    printf "\r[✓] Done!          \n"
}

press_q_to_quit() {
    read -n 1 -s -p "Press q to quit or any other key to continue... " key
    echo
    if [[ "$key" == "q" || "$key" == "Q" ]]; then
        echo "Goodbye."
        exit 0
    fi
}
 # Define colors using tput
red=$(tput setaf 1)
green=$(tput setaf 2)
blue=$(tput setaf 4)
yellow=$(tput setaf 3)
cyan=$(tput setaf 6)
nc=$(tput sgr0) # Reset color

banner=$(cat <<"EOF"
+==========================================================================+
|  __        __   _                            _          _   _            |
|  \ \      / ___| | ___ ___  _ __ ___   ___  | |_ ___   | |_| |__   ___   |
|   \ \ /\ / / _ | |/ __/ _ \| '_ ` _ \ / _ \ | __/ _ \  | __| '_ \ / _ \  |
|    \ V  V |  __| | (_| (_) | | | | | |  __/ | || (_) | | |_| | | |  __/  |
|     \_/\_/ \___|_|\___\___/|_| |_| |_|\___|  \__\___/   \__|_| |_|\___|  |
|   __  __               ____                                              |
|  |  \/  | __ _ _ __   |  _ \ __ _  __ _  ___ ___                         |
|  | |\/| |/ _` | '_ \  | |_) / _` |/ _` |/ _ / __|                        |
|  | |  | | (_| | | | | |  __| (_| | (_| |  __\__ \                        |
|  |_|  |_|\__,_|_| |_| |_|   \__,_|\__, |\___|___/                        |
|                                   |___/                                  |
+==========================================================================+
EOF
)
# ------------------------------------- main script -------------------------------------

while true; do
clear
echo "$banner"
echo
echo "welcome to the man pages for the interactive instalers. Here you can find all the information about each of the installers"

echo "Which one can we help you with?:"
echo "1) I-Installer"
echo "2) Ventoy-interactive"
echo "3) Tool Box"
echo "4) Terminal-Tutor"
echo "5) "
echo "   exit"

# Prompt for user input using the `read` command
read -p "Select an option (1, 2, 3, 4, or 5): " option

case $option in
    1)
sleep 3 &
spinner
sleep 1
clear

cat <<"EOF"
+============================================================+
|   __  __                 ____                              |
|  |  \/  |  __ _  _ __   |  _ \  __ _   __ _   ___  ___     |
|  | |\/| | / _` || '_ \  | |_) |/ _` | / _` | / _ \/ __|    |
|  | |  | || (_| || | | | |  __/| (_| || (_| ||  __/\__ \    |
|  |_|  |_| \__,_||_| |_| |_|    \__,_| \__, | \___||___/    |
|                                       |___/                |
|   ___       ___              _          _  _               |
|  |_ _|     |_ _| _ __   ___ | |_  __ _ | || |  ___  _ __   |
|   | | _____ | | | '_ \ / __|| __|/ _` || || | / _ \| '__|  |
|   | ||_____|| | | | | |\__ \| |_| (_| || || ||  __/| |     |
|  |___|     |___||_| |_||___/ \__|\__,_||_||_| \___||_|     |
+============================================================+
EOF
    echo

    echo ${cyan} "--- DESCRIPTION ---
${nc}
i-installer is an interactive, menu-driven Bash script that allows users to
install one of several popular web browsers through a terminal-based interface.

The installer provides visual feedback using ASCII art, colorized output,
and loading animations to guide the user through the installation process.

Supported browsers include:

- ${red}Opera

- ${blue}G${red}o${yellow}o${blue}g${green}l${red}e ${nc}Chrome

- ${blue}Microsoft Edge

- ${red}Vivaldi

- ${yellow}Brave"

echo ${nc}

    echo ${cyan} "--- FEATURES ---
${nc}
- Interactive menu selection

- Terminal-based user interface

- ASCII art banners for each browser

- Loading animations and progress indicators

- Uses system package managers (apt, snap, dpkg)"

echo

    echo ${cyan} "--- REQUIREMENTS ---
 ${nc}
- Bash (version 4.0 or later)

- sudo privileges

- Internet connection

- Debian-based Linux distribution (Ubuntu, Debian, derivatives)"


    echo ""

    echo ${cyan} "--- Usage ---
    ${nc}
    you must be in the same directory as the file so you can execute it properly

    command: .bash I-Installer.sh"

echo

    echo ${cyan} "--- NOTES ---
${nc}
- Some installations rely on Snap while others use APT

- Package sources are added automatically when required

- The script does not remove existing browser installations

- Review commands before running if system changes are a concern"

sleep 2

echo

 echo ${red}
    cat <<"EOF"

+========================================================================+
|                                                                        |
|   ____  ___  ____    ____  _         _     ___  __  __  _____  ____    |
|  |  _ \|_ _|/ ___|  / ___|| |       / \   |_ _||  \/  || ____||  _ \   |
|  | | | || | \___ \ | |    | |      / _ \   | | | |\/| ||  _|  | |_) |  |
|  | |_| || |  ___) || |___ | |___  / ___ \  | | | |  | || |___ |  _ <   |
|  |____/|___||____/  \____||_____|/_/   \_\|___||_|  |_||_____||_| \_\  |
|                                                                        |
+========================================================================+
EOF


    echo ${nc} "This script is provided as-is, without warranty of any kind. The author is not responsible for system changes or package conflicts."
sleep 4

 read -rp "Press Enter to return to menu..."
 ;;

    2)

sleep 3 &
spinner
sleep 1
clear
 echo
    cat <<"EOF"

+================================================================+
|   __  __                 ____                                  |
|  |  \/  |  __ _  _ __   |  _ \  __ _   __ _   ___  ___         |
|  | |\/| | / _` || '_ \  | |_) |/ _` | / _` | / _ \/ __|        |
|  | |  | || (_| || | | | |  __/| (_| || (_| ||  __/\__ \        |
|  |_|  |_| \__,_||_| |_| |_|    \__,_| \__, | \___||___/        |
|  __     __            _               |___/                    |
|  \ \   / /___  _ __  | |_  ___   _   _                         |
|   \ \ / // _ \| '_ \ | __|/ _ \ | | | |                        |
|    \ V /|  __/| | | || |_| (_) || |_| |                        |
|     \_/  \___||_| |_| \__|\___/  \__, |                        |
|   ___         _                  |___/    _    _               |
|  |_ _| _ __  | |_  ___  _ __  __ _   ___ | |_ (_)__   __ ___   |
|   | | | '_ \ | __|/ _ \| '__|/ _` | / __|| __|| |\ \ / // _ \  |
|   | | | | | || |_|  __/| |  | (_| || (__ | |_ | | \ V /|  __/  |
|  |___||_| |_| \__|\___||_|   \__,_| \___| \__||_|  \_/  \___|  |
+================================================================+
EOF
       echo

    echo ${cyan} "--- DESCRIPTION ---
${nc}
Ventoy interactive is used to download the ventoy package from the repository universe on GitHub
"

    echo ${cyan} "--- FEATURES ---
${nc}
- Interactive menu selection

- Terminal-based user interface

- ASCII art banners

- Loading animations and progress indicators"

echo

    echo ${cyan} "--- REQUIREMENTS ---
 ${nc}
- Bash (version 4.0 or later)

- sudo privileges

- Internet connection

- Debian-based Linux distribution (Ubuntu, Debian, derivatives)"


    echo

    echo ${cyan} "--- Usage ---
    ${nc}
    you must be in the same directory as the file so you can execute it properly or copy the .sh file path

    Best usage: The .desktop entry

    command: bash Ventoy-interactive.sh"

echo

    echo ${cyan} "--- NOTES ---
${nc}
- Some downloads may appear in a different location

- Package sources are added automatically when required

- The script does not remove existing files except for those installed

- Review commands before running if system changes are a concern"

sleep 2
echo
 echo ${red}
    cat <<"EOF"

+========================================================================+
|                                                                        |
|   ____  ___  ____    ____  _         _     ___  __  __  _____  ____    |
|  |  _ \|_ _|/ ___|  / ___|| |       / \   |_ _||  \/  || ____||  _ \   |
|  | | | || | \___ \ | |    | |      / _ \   | | | |\/| ||  _|  | |_) |  |
|  | |_| || |  ___) || |___ | |___  / ___ \  | | | |  | || |___ |  _ <   |
|  |____/|___||____/  \____||_____|/_/   \_\|___||_|  |_||_____||_| \_\  |
|                                                                        |
+========================================================================+
EOF


    echo ${nc} "This script performs destructive disk operations
The author assumes no responsibility for data loss.
Always verify the target disk before proceeding."

echo
 read -rp "Press Enter to return to menu..."
 ;;

     3)

sleep 3 &
spinner
sleep 1
clear
 echo
    cat <<"EOF"
+=====================================================+
|   __  __               ____                         |
|  |  \/  | __ _ _ __   |  _ \ __ _  __ _  ___  ___   |
|  | |\/| |/ _` | '_ \  | |_) / _` |/ _` |/ _ \/ __|  |
|  | |  | | (_| | | | | |  __/ (_| | (_| |  __/\__ \  |
|  |_|  |_|\__,_|_| |_| |_|   \__,_|\__, |\___||___/  |
|   _____           _   ____        |___/             |
|  |_   _|__   ___ | | | __ )  _____  __              |
|    | |/ _ \ / _ \| | |  _ \ / _ \ \/ /              |
|    | | (_) | (_) | | | |_) | (_) >  <               |
|    |_|\___/ \___/|_| |____/ \___/_/\_\              |
+=====================================================+
EOF
       echo

    echo ${cyan} "--- DESCRIPTION ---
${nc}
The Tool Box is a hub file that is used to launch different activities.
"

    echo ${cyan} "--- FEATURES ---
${nc}
- Update tools

    This option is used to teach or automatically update and upgrade the system

- System Playground
    The system playground is a place where users are taught a selection of commands that linux users run in day to day life

- more coming sooon

- coming soon"

echo

    echo ${cyan} "--- REQUIREMENTS ---
 ${nc}
- Bash (version 4.0 or later)

- sudo privileges

- Internet connection

- Debian-based Linux distribution (Ubuntu, Debian, derivatives)"


    echo

    echo ${cyan} "--- Usage ---
    ${nc}
- you must be in the same directory as the file so you can execute it properly or copy the .sh file path

- Best usage: The .desktop entry

- command: bash toolbox.sh"

echo

    echo ${cyan} "--- NOTES ---
${nc}
- the commands run in system playground are for EDUCATIONAL PURPOSES ONLY

${red} DO NOT RUN ONE OF THEM ON ANY SYSTEM!!!
${nc}

- Package sources are added automatically when required

- The script does not remove existing files except for those installed

- Review commands before running if system changes are a concern"

    sleep 2
echo
 echo ${red}
    cat <<"EOF"

+========================================================================+
|                                                                        |
|   ____  ___  ____    ____  _         _     ___  __  __  _____  ____    |
|  |  _ \|_ _|/ ___|  / ___|| |       / \   |_ _||  \/  || ____||  _ \   |
|  | | | || | \___ \ | |    | |      / _ \   | | | |\/| ||  _|  | |_) |  |
|  | |_| || |  ___) || |___ | |___  / ___ \  | | | |  | || |___ |  _ <   |
|  |____/|___||____/  \____||_____|/_/   \_\|___||_|  |_||_____||_| \_\  |
|                                                                        |
+========================================================================+
EOF


    echo ${nc} "The system playground teaches a highly destructive command The author is not responsible for any damage if a user runs this command."

 read -rp "Press Enter to return to menu..."
    ;;
    4)

sleep 3 &
spinner
sleep 1
clear
 echo
    cat <<"EOF"
+========================================================================+
|   __  __               ____                                            |
|  |  \/  | __ _ _ __   |  _ \ __ _  __ _  ___  ___                      |
|  | |\/| |/ _` | '_ \  | |_) / _` |/ _` |/ _ \/ __|                     |
|  | |  | | (_| | | | | |  __/ (_| | (_| |  __/\__ \                     |
|  |_|__|_|\__,_|_| |_| |_| _ \__,_|\__, |\___||___/     _               |
|  |_   _|__ _ __ _ __ ___ (_)_ __  |___/| | |_   _|   _| |_ ___  _ __   |
|    | |/ _ \ '__| '_ ` _ \| | '_ \ / _` | |   | || | | | __/ _ \| '__|  |
|    | |  __/ |  | | | | | | | | | | (_| | |   | || |_| | || (_) | |     |
|    |_|\___|_|  |_| |_| |_|_|_| |_|\__,_|_|   |_| \__,_|\__\___/|_|     |
+========================================================================+
EOF
           echo

    echo ${cyan} "--- DESCRIPTION ---
${nc}
Terminal Tutor is the first file that is auto-made on first run. This is used to teach the user how to set up the .desktop files and once you finish one of them, you will be let go to finish the rest.
"

    echo ${cyan} "--- FEATURES ---
${nc}
- Interactive menu selection

- Terminal-based user interface

- ASCII art banners

- Easy to understand"

echo

    echo ${cyan} "--- REQUIREMENTS ---
 ${nc}
- Bash (version 4.0 or later)

- sudo privileges

- Internet connection

- Debian-based Linux distribution (Ubuntu, Debian, derivatives)"


    echo

    echo ${cyan} "--- Usage ---
    ${nc}
- you must be in the same directory as the file so you can execute it properly or copy the .sh file path

- Best usage: The .desktop entry

- command: bash Terminal-Tutor.sh"

echo

    echo ${cyan} "--- NOTES ---
${nc}
- Some downloads may appear in a different location

- Package sources are added automatically when required

- The script does not remove existing files except for those installed

- Review commands before running if system changes are a concern"

sleep 5
 read -rp "Press Enter to return to menu..."
    ;;

    *)
        echo "Invalid option. Please choose a valid number between 1 and 4."
        ;;
esac
done
