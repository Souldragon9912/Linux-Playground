#!/bin/bash

# this is a file that can be used to guide through the setup process and installation of Immich.
# if you are new to docker and immich you can folow along or copy and pase this into the terminal

clear
 # Define colors using tput
red=$(tput setaf 1)
green=$(tput setaf 2)
blue=$(tput setaf 4)
yellow=$(tput setaf 3)
cyan=$(tput setaf 6)
nc=$(tput sgr0) # Reset color

spinner() {
    local pid=$!
    local spin='|/-\'
    local i=0

    while kill -0 "$pid" 2>/dev/null; do
        i=$(( (i+1) %4 ))
        printf "\r[%c] Loading..." "${spin:$i:1}"
        sleep 1
    done
    printf "\r[✓] Done!          \n"
}

 echo "${blue}"

# Define the ASCII art banner to be placed at the top of the script
cat <<'EOF'
+===========================================================================================================+
|                                                                                                           |
|                           $$\                                                     $$\                     |
|                           $$ |                                                    $$ |                    |
|   $$\  $$\  $$\  $$$$$$\  $$ | $$$$$$$\  $$$$$$\  $$$$$$\$$$$\   $$$$$$\        $$$$$$\    $$$$$$\        |
|   $$ | $$ | $$ |$$  __$$\ $$ |$$  _____|$$  __$$\ $$  _$$  _$$\ $$  __$$\       \_$$  _|  $$  __$$\       |
|   $$ | $$ | $$ |$$$$$$$$ |$$ |$$ /      $$ /  $$ |$$ / $$ / $$ |$$$$$$$$ |        $$ |    $$ /  $$ |      |
|   $$ | $$ | $$ |$$   ____|$$ |$$ |      $$ |  $$ |$$ | $$ | $$ |$$   ____|        $$ |$$\ $$ |  $$ |      |
|   \$$$$$\$$$$  |\$$$$$$$\ $$ |\$$$$$$$\ \$$$$$$  |$$ | $$ | $$ |\$$$$$$$\         \$$$$  |\$$$$$$  |      |
|    \_____\____/  \_______|\__| \_______| \______/ \__| \__| \__| \_______|         \____/  \______/       |
|                                                                                                           |
|                                                                                                           |
|                                                                                                           |
|   $$$$$$\            $$\                                              $$\     $$\                         |
|   \_$$  _|           $$ |                                             $$ |    \__|                        |
|     $$ |  $$$$$$$\ $$$$$$\    $$$$$$\   $$$$$$\  $$$$$$\   $$$$$$$\ $$$$$$\   $$\ $$\    $$\  $$$$$$\     |
|     $$ |  $$  __$$\\_$$  _|  $$  __$$\ $$  __$$\ \____$$\ $$  _____|\_$$  _|  $$ |\$$\  $$  |$$  __$$\    |
|     $$ |  $$ |  $$ | $$ |    $$$$$$$$ |$$ |  \__|$$$$$$$ |$$ /        $$ |    $$ | \$$\$$  / $$$$$$$$ |   |
|     $$ |  $$ |  $$ | $$ |$$\ $$   ____|$$ |     $$  __$$ |$$ |        $$ |$$\ $$ |  \$$$  /  $$   ____|   |
|   $$$$$$\ $$ |  $$ | \$$$$  |\$$$$$$$\ $$ |     \$$$$$$$ |\$$$$$$$\   \$$$$  |$$ |   \$  /   \$$$$$$$\    |
|   \______|\__|  \__|  \____/  \_______|\__|      \_______| \_______|   \____/ \__|    \_/     \_______|   |
|                                                                                                           |
|                                                                                                           |
|                                                                                                           |
|   $$\                       $$\               $$\ $$\                                                     |
|   \__|                      $$ |              $$ |$$ |                                                    |
|   $$\ $$$$$$$\   $$$$$$$\ $$$$$$\    $$$$$$\  $$ |$$ | $$$$$$\   $$$$$$\                                  |
|   $$ |$$  __$$\ $$  _____|\_$$  _|   \____$$\ $$ |$$ |$$  __$$\ $$  __$$\                                 |
|   $$ |$$ |  $$ |\$$$$$$\    $$ |     $$$$$$$ |$$ |$$ |$$$$$$$$ |$$ |  \__|                                |
|   $$ |$$ |  $$ | \____$$\   $$ |$$\ $$  __$$ |$$ |$$ |$$   ____|$$ |                                      |
|   $$ |$$ |  $$ |$$$$$$$  |  \$$$$  |\$$$$$$$ |$$ |$$ |\$$$$$$$\ $$ |                                      |
|   \__|\__|  \__|\_______/    \____/  \_______|\__|\__| \_______|\__|                                      |
|                                                                                                           |
+===========================================================================================================+
EOF

        echo "${nc}"
	echo Welcome! Here you can choose between 4 different Web Browsers to install.
	echo "the next version will allow for more then just this. keep an eye out."



# ------------------------------- Installer scripts------------------------------

sleep 3 &
spinner
echo
echo "Please choose an option to install:"
echo "1) Opera"
echo "2) Chrome"
echo "3) Microsoft Edge"
echo "4) Vivaldi"
echo "5) Brave"

# Prompt for user input using the `read` command
read -p "Select an option (1, 2, 3, 4, or 5): " option

# Based on the user choice, execute the corresponding installation
case $option in
    1)
sleep 3 &
spinner
sleep 1
    clear
 echo "${red}"
cat <<'EOF'

                                          ..:-=+****+=-:..
                                     .:=********************=:.
                                  .-+****************##########+-.
                                :+**************##%%%#%%#%%%%%#%%#+:
                              :***************+=-..:-=+############%*-
                            :+************+=.           :+############*:
                           -*************-.               :*############-
                         .=************+:                   :############=.
                         -************+                      :############=.
                       .:*************                        :############-
                       .*************.                         -***********#.
                       *************-                          .*************
                      .*************:                           -************.
                      -************=.                           :************-
                      +************=.                           :************+
                      *************-                            :+++********+*
                      +************=                            :++++++++++++=
                      -************+.                           :++++++++++++-
                      .*************:                           :++++++++++++.
                       *************-                          .+++++++++++++
                       .*************.                         :++++++++++++.
                        -#*##******#**                        .++++++++++++:
                         =############*                      .++++++++++++-
                         .=############*.                   :++++++++++++-.
                           -*###########*-                .=++++++++++++-
                            :+############*-.           .-++++++++++++=.
                              -*#############+--:...:--+++++++++++++=:
                                :+#############**+++++++++++++++++=:
                                  .-###############****+++++****-.
                                     .:=####################=:.
                                          .::=+*#%%#*+=-:.
                                                                    Opera, Your personal browser
EOF
 echo "${nc}"
        echo "Let's get opera installed for ya."
        # Insert the command to install Option 1 here
        echo installing
        symbols=("Loading… █▒▒▒▒▒▒▒▒▒" "10 ███▒▒▒▒▒▒▒" "30 █████▒▒▒▒▒"
 "50 ███████▒▒▒" "100 ██████████")
i=0
duration=5
interval=1
iterations=$((duration / interval))

while [[ $iterations -gt 0 ]]; do
  printf "\rLoading ${symbols[i]}"
  ((i = (i + 1) % 6))
  sleep $interval
  ((iterations--))
done
        sudo snap install opera
        echo "All done, Enjoy your time using opera."
        sleep 3
        clear
      exit 1
        ;;
    2)
    clear
        # Insert the command to install Option 2 here
# tput colors
RED=$(tput setaf 1)
YELLOW=$(tput setaf 3)
GREEN=$(tput setaf 2)
BLUE=$(tput setaf 4)
BOLD=$(tput bold)
RESET=$(tput sgr0)

sleep 3 &
spinner
sleep 1
clear

cat <<EOF
${RED}${BOLD}                               xxxxxxxxxxxxxxxxxxxx
                         xxxxxxxxxxxxxxxxxxxx+xx+xxxx+xx
                     xxxxxxxxxxxxxxxxxxxxxxxxxxxx+x+xx+xx+xx
                  xxxxxxxxxxxxxxxxxxxxxxxxxx+x+xxxxx+xx+xx+x+xx+
               xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+x+xx+xx+xx+x+x+x+
             xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+xxxxxx+x+xx+x+x+x+x+xx
           xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+xxxxx+x+xxxxx+xx+x+x+x+x+++x
          xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+xxxxxx+x+xx+xx+x+x+x+x+x++x
        xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+xx+xx+x+xx+x+x+x+x+x++x+++
      xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+xxxx+xxxxx+xxxx+xx+x+x+x+x+x++x+x++
      xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+xxx+x+xxx+x+x+xx+x+x+x+x+x++++x+
 ${GREEN}   ++${RED}xxxxxxxxxxxxxxxxxxxxxxxxxxx++;${YELLOW} :::::::::;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
  ${GREEN}  +++${RED}xxxxxxxxxxxxxxxxxxxxxxx;${BLUE}:::::::::::::::::::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;;;;;
  ${GREEN} +++++${RED}xxxxxxxxxxxxxxxxxxx+${BLUE}::::::::;+++++++;::::::::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;;;
 ${GREEN} +++++++${RED}xxxxxxxxxxxxxxxx+${BLUE}::::::++xxxxxxxxxxxxx++;:::::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;;
 ${GREEN}+++++++++${RED}xxxxxxxxxxxxxx;${BLUE}::::;+xxxxxxxxxxxxxxxxxxx+;::::;${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;
${GREEN} ++++++++++${RED}xxxxxxxxxxx+;${BLUE}::::+xxxxxxxxxxxxxxxxxxxxxxx+:::::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;
${GREEN}++++++++++++${RED}xxxxxxxxxx${BLUE}::::;xxxxxxxxxxxxxxxxxxxxxxxxxxx;::::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;
${GREEN}+++++++++++++${RED}xxxxxxxx;${BLUE}:::;xxxxxxxxxxxxxxxxxxxxxxxxxxxxx;:::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;
${GREEN}++++++++++++++${RED}xxxxxx+${BLUE}::::+xxxxxxxxxxxxxxxxxxxxxxxxxxxxx+::::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;
${GREEN}+++++++++++++++${RED}xxxxx+${BLUE}:::;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;:::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;
${GREEN}++++++++++++++++${RED}xxxx;${BLUE}:::;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;:::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;
${GREEN}++++++++++x+x+x++${RED}xxx;${BLUE}:::;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;:::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;
${GREEN}+++++++x+++++++x++${RED}xx+${BLUE}:::;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;:::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;
${GREEN}+++x+x+++x++x+++x++${RED}x+${BLUE}::::+xxxxxxxxxxxxxxxxxxxxxxxxxxxxx+;:::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;
${GREEN}+x+++++x++x++x+x+x++${RED}x;${BLUE}:::;xxxxxxxxxxxxxxxxxxxxxxxxxxxxx;:::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;
${GREEN}+++x+x++x++x+++++x+x++;${BLUE}:::;xxxxxxxxxxxxxxxxxxxxxxxxxxx;::::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;
${GREEN} +++++x++x++x+xx+x+xx++;${BLUE}::::+xxxxxxxxxxxxxxxxxxxxxxx+:::::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;
 ${GREEN}x+x+x+x++x+x+x+x+x+xx++;${BLUE}::::;+xxxxxxxxxxxxxxxxxxx+;::::${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;;
 ${GREEN} +x+++x+x+x+x+x+x+x+xxxx+${BLUE}::::::++xxxxxxxxxxxxx++ ;:::::${GREEN}+${YELLOW};;;;;;;;;;;;;;;;;;;;;;;
  ${GREEN} +xx+x+xx+x+xxx+x+x+x+xxx+${BLUE}::::::::;+++++++;::::::::${GREEN}++${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;;
  ${GREEN}  +x+x+x+x+x+x+xxxxxxx+xxxx+;${BLUE}:::::::::::::::::::;${GREEN}+xx${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;
   ${GREEN} x+x+x+x+x+xxx+x+x+x+xx+xxxxxx++;${BLUE}:::::::::;${GREEN}++xxxx+${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;;
   ${GREEN}   xx+xxxxx+xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;;
     ${GREEN} x+x+x+x+x+x+x+x+xxxxxx+xxxxxxxxxxxxxxxxxxxxx+${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;;
     ${GREEN}   xxxxxxxxxxxxxxx+x+xxxxxxxxxxxxxxxxxxxxxxx+${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;
      ${GREEN}   xx+x+xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;;
      ${GREEN}     xxxx+x+x+xxxxxxxxxxxxxxxxxxxxxxxxxxx+${YELLOW} ;;;;;;;;;;;;;;;;;;;;;;
         ${GREEN}    xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+${YELLOW} ;;;;;;;;;;;;;;;;;;;;;
          ${GREEN}     xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx+${YELLOW} ;;;;;;;;;;;;;;;;;;;;
            ${GREEN}     xxxxxxxxxxxxxxxxxxxxxxxxxxx+${YELLOW} ;;;;;;;;;;;;;;;;;;;
            ${GREEN}         xxxxxxxxxxxxxxxxxxxxxx+${YELLOW} ;;;;;;;;;;;;;;;;
               ${GREEN}          xxxxxxxxxxxxxxxxx${YELLOW} ;;;;;;;;;;;;;;
                   ${GREEN}           +xxxxxxxxxx${YELLOW} ;;;;;;;;;;${RESET}
                                                        Google Chrome, The browser built to be fast
EOF

                echo installing chrome, this may or may not work.
        symbols=("Loading… █▒▒▒▒▒▒▒▒▒" "10 ███▒▒▒▒▒▒▒" "30 █████▒▒▒▒▒"
 "50 ███████▒▒▒" "100 ██████████")
i=0
duration=5
interval=1
iterations=$((duration / interval))

while [[ $iterations -gt 0 ]]; do
  printf "\rLoading ${symbols[i]}"
  ((i = (i + 1) % 6))
  sleep $interval
  ((iterations--))
done

       wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb

       sudo dpkg -i google-chrome-stable_current_amd64.deb

       sudo apt-get install -f
       sleep 2
       echo "chrome should now be ready for you to use"
sleep 3
clear
        ;;
    3)
       sleep 3 &
spinner
sleep 1
sleep 3 &
spinner
sleep 1
clear
           echo "${blue}"
        # Insert the command to install Option 2 here
        cat <<'EOF'

                              .:;;;;;+;++++;;;;;;:.
                        .::+++++++++++++++++++++++++++;:.
                     .:;+;++;+++++++++++++++++++++++++++++;:
                  .:;++;+;+;+;+;+;+;++;++++++++++++++++++;+;+;:
                .;;+;;+;+;+;+;+;++++;+++;+;++++++++++++;+;;;;;;;:
              :;;++;+;+;++;+;+;+;+;+;+++++++++++++++++;+;+;;;;;;;;:.
            .;;+;;+;+;;+;+;++;++;++;++;+++++;+++++++++;+;;;;;;;;;;;;:
           :;;+;+;+;;+;;+;+;+;+;+;++;+++;+;++++++++++;+;;;;;;;;;;;;;;;.
          ;+++;+;+;+;+;+;+;+;+;+;+;+++;+++++;+++++++++;+;;;;;;;;;;;;;;;:
        .;;+;;+;+;+;+++xxxxxx+++++++++++++;+++++++++;+;;;;;;;;;;;;;;;;;;:
       .;;+;+;+++XXXXXXXXXXXxXXXXXXx+++++++++++++++++;+;;;;;;;;;;;;;;;;;;:
      .;++;++XXXXXXXXXxXxxxxxxxxxxxXXXXx++++++++++++;+;;;;;;;;;;;;;;;;;;;;:
     .;;++xXXXXXXxXxxxxxxxxxxxxxxxxxxxxXXX++++++++++++;+;;;;;;;;;;;;;;;;;;;.
     :++xXXXXXXxxxxxxxxxxxxxxxxxxxxxxxxxxxXX+++++++++;+;;;;;;;;;;;;;;;;;;;;:
     ;+XXXXXXxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxXx++++++++;+;;;;;;;;;;;;;;;;;;;;.
    :+XXXXXxxxxxxxxxxxxxxxxxxxx+xx++:      :+xx++++++++++;;;;;;;;;;;;;;;;;;;:
   .;XXXXXxXxxxxxxxxxxxxxxxxxxxxX;.          .;x+++++++;+;+;;;;;;;;;;;;;;;;;:
   .xXXXXxxxxxxxxxxxxxxxxxxxxxXX:              .++++++++++;+;;;;;;;;;;;;;;;;:
   :xXXXxXxxxxxxxxxxxxxxxxxxX$X;                :+++++++++++;+;;;;;;;;;;;;;;.
   :xXxXxXxXxxxxxxxxxxxxxxxX$$X.                .;+++++++++++;+;;;;;;;;;;;;;.
   :xXXXXxXxXxXxxxxxxxxxxxX$$XX.                .;++++++++++++++;+;+;;;;;;;.
   :xXxXxXxXxXxXxxxxxxxxxX$X$XX:                :++++++++++++++++++;+;+;+;:
   :xXxXXXXxXxXxXxXxxxxxX$$XXXX+               .+++++++++++++++++++++++++:
   .+XXXxXxXXxXxXxxXxxxX$$X$XXXX:             :++++++++++++++++++++++++;.
    ;XXXXxXxXXxXxXxxXxXXX$XXXXXXX:           .;++++++++++++++++++++++;.
    .xXxXXXXXXXxXxXxXxxX$XXXXXXXXX:            :;+++++++++++++++++;:.
     :XXXXXXxXXXXXXXxXx$$XXXXXXXXXX;                ::;;;;;;;;:.
     .+XXXXXXXxXxXxXXxX$$XXXXXXXXXXXX:
      .xXXXXXXXXXXXxXXxX$$XXXXXXXXXXXXX:.
       .+XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX+;                          :.
        .+XXXXXXXXXXxXxXX$XXXXXXXXXXXXXXXXXXX+:.                .:+X$$X.
         .+XXXXXXXXXXXXXX$XXXXXXXXXXXXXXXXXXXXXXXXXx++;;;;++XXX$X$X$$x.
           ;xXXXXXXXXXXXxX$XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX$XXX$$;
            .+XXXXXXXXXXXXX$$XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX$$$x.
              :+XXXXXXXXXXXXX$XXXXXXXXXXXXXXXXXXXXXXXXXX$XXX$$X$X:
                :+XXXXXXXXXXX$$XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX$X:
                  .;xXXXXXXXXXXX$XXXXXXXXXXXXXXXXXXXXXXX$X$X+.
                     .;XXXXXXXXXXX$X$XXXXXXXXXXXXXXXXXXX$+.
                        .:;xXXXXXXXXXX$X$X$XXXXXX$X$X+;.
                              .;+xxxxxxxxXXXXXXX;:
                                                            Microsoft Edge, A new way to pilot the web
EOF
 echo "${nc}"
                echo installing MS Edge, this may or may not work.
        symbols=("Loading… █▒▒▒▒▒▒▒▒▒" "10 ███▒▒▒▒▒▒▒" "30 █████▒▒▒▒▒"
 "50 ███████▒▒▒" "100 ██████████")
i=0
duration=5
interval=1
iterations=$((duration / interval))

while [[ $iterations -gt 0 ]]; do
  printf "\rLoading ${symbols[i]}"
  ((i = (i + 1) % 6))
  sleep $interval
  ((iterations--))
done

curl -fsSL https://packages.microsoft.com/keys/microsoft.asc | sudo gpg --dearmor -o /usr/share/keyrings/microsoft.gpg

echo "deb [arch=amd64 signed-by=/usr/share/keyrings/microsoft.gpg] https://packages.microsoft.com/repos/edge stable main" | sudo tee /etc/apt/sources.list.d/microsoft-edge.list

sudo apt update
sudo apt install microsoft-edge-stable -y

        echo "thank chatGPT for the help to automate this."
sleep 3
clear
        exit 1
        ;;

    4)
sleep 3 &
spinner
sleep 1
clear
echo "${red}"
cat <<'EOF'


                     :+******-.                                       .=+****+-
                   -***********+                                    :***********+.
                  =**************.                                 -**************.
                 :****************.                               .***************=
                 :*****************.                              :***************+
                 .******************.                             .***************=
                  :******************:                             :*************+.
                   :******************:                             -***********+.
                    :******************:                            .**********+
                     .******************-                           .*********+
                      .******************-                          .********=
                       .******************=                         :*******=
                        .******************+                       .*******-
                         .+*****************+                     .+******-
                          .+******************.                  -*******-
                            +*******************:             .=********:
                             +*********************+-.   ..-+**********:
                              +***************************************.
                               =*************************************.
                                =**********************************+.
                                 -********************************+.
                                  -******************************+.
                                   :****************************+.
                                    :**************************+
                                     .************************+
                                      .**********************+
                                       .+*******************=
                                        .+*****************=
                                         .+***************-
                                          .+*************-
                                            -**********+.
                                              .=+***+:
                                                              Vivaldi, The only web browser powerful enough for you!
EOF
echo "${nc}"
        echo "Let's get Vivaldi installed for ya."
        # Insert the command to install Option 1 here
        echo installing
        symbols=("Loading… █▒▒▒▒▒▒▒▒▒" "10 ███▒▒▒▒▒▒▒" "30 █████▒▒▒▒▒"
 "50 ███████▒▒▒" "100 ██████████")
i=0
duration=5
interval=1
iterations=$((duration / interval))

while [[ $iterations -gt 0 ]]; do
  printf "\rLoading ${symbols[i]}"
  ((i = (i + 1) % 6))
  sleep $interval
  ((iterations--))
done

sudo snap install vivaldi
echo "Vivaldi should be installed now. Launching now..."

sleep 2

        ;;
5)
sleep 3 &
spinner
sleep 1
clear
echo "${yellow}"
cat <<'EOF'
                                    .:::::::::----------------:.
                                  .-+++************************+:.
                                .:=+++++*************************=.
                               .-++++++****************************-.
                              :+++++++++*****************************.
                    .+++++++++++++++++++**************************************=.
                 ..=++++++++++++++++++++****************************************=..
                .-+++++++++++++++++++++*******+++==++*****************************-..
              .:+++++++++++++++. ..:==+++++=..        .:=++++++=:.  -***************:
              .++++++++++++++-.                                       +*************=
               .+++++++++++=:                                         .-***********+.
                :+++++++++=.                                            :+*********:.
               .=++++++++-    .::::-----:...           ...:--------::    .=********=.
               -++++++++:      .:-=+++++++++=-       .=+*********==:.      -********:
              .++++++++.            .:-=++++++       :******=--.            -********.
              =+++++++:                 ..=+++        ***=:.                 +*******-
              :+++++++=                   .=+:        +*+.                  .********.
              .=+++++++=:                 :=+.        .*+.                .-********-
               :+++++++++-.             .:=+=.        .**=.              :+*********.
                =++++++++++:.          .:+++:.        .=**+.           .=**********-.
                :++++++++++++..        .++++:         .:***=.         -************:.
                .=++++++++++++=.       .++++:..      ..=***+..      .*************-.
                .:++++++++++++++=      ...-+++++++++*****=..      .+**************:.
                 .=++++++++++++++-          .++++*****+.          =**************=.
                 .:+++++++++++++=              .****:.            .+************+:
                  .=++++++++++++.              .:+=..              :************=.
                  .-+++++++++++=              .:****:.             .***********+:
                   .=+++++++++++.           ..+++*****:.           -***********+.
                   .-++++++++++++:       ..-++++********-..      .-************:
                    .=++++++++++++=:..::=+++++==...:==*****=::..-+************+.
                    .-++++++++++++++++++++=-..        ..=+********************:
                     .+++++++++++++++++-:.                .-=*****************.
                      -++++++++++++++++:                    :****************:
                      .+++++++++++++++++=:.              .=******************.
                       -+++++++++++++++++++-.         .:=*******************:
                       .=++++++++++++++++++++=:      -+********************=.
                        .=++++++++++++++++++++++- .-+*********************=..
                        ..=+++++++++++++++++++++*+***********************=..
                          .:=++++++++++++++++++++**********************+:.
                            ..-++++++++++++++++++********************-..
                               .:=+++++++++++++++*****************=:.
                                ...-+++++++++++++***************:..
                                     .=++++++++++************=.
                                       .:=+++++++*********+..
                                          .-=++++******+:.
                                             .-++***+-.
                                                .:..            Brave, The browser that puts you first
EOF
echo "${nc}"
        echo "Let's get Brave installed for ya."
        # Insert the command to install Option 1 here
        echo installing
        symbols=("Loading… █▒▒▒▒▒▒▒▒▒" "10 ███▒▒▒▒▒▒▒" "30 █████▒▒▒▒▒"
 "50 ███████▒▒▒" "100 ██████████")
i=0
duration=5
interval=1
iterations=$((duration / interval))

while [[ $iterations -gt 0 ]]; do
  printf "\rLoading ${symbols[i]}"
  ((i = (i + 1) % 6))
  sleep $interval
  ((iterations--))
done

sudo apt install curl

sudo curl -fsSLo /usr/share/keyrings/brave-browser-archive-keyring.gpg https://brave-browser-apt-release.s3.brave.com/brave-browser-archive-keyring.gpg

sudo curl -fsSLo /etc/apt/sources.list.d/brave-browser-release.sources https://brave-browser-apt-release.s3.brave.com/brave-browser.sources

sudo apt update

sudo apt install brave-browser

echo "Brave should be installed now. Launching now..."

sleep 2

        ;;
    *)
        echo "Invalid option. Please choose a valid number between 1 and 4."
        ;;
esac
