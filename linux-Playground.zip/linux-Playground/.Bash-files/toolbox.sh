#!/usr/bin/env bash


spinner() {
    local pid=$!
    local spin='|/-\'
    local i=0

    while kill -0 "$pid" 2>/dev/null; do
        i=$(( (i+1) %4 ))
        printf "\r[%c] Loading..." "${spin:$i:1}"
        sleep 1
    done
    printf "\r[✓] Done!          \n"
}


clear
cat <<"EOF"
+===================================================================================+
|  __        __     _                                _           _    _             |
|  \ \      / /___ | |  ___  ___   _ __ ___    ___  | |_  ___   | |_ | |__    ___   |
|   \ \ /\ / // _ \| | / __|/ _ \ | '_ ` _ \  / _ \ | __|/ _ \  | __|| '_ \  / _ \  |
|    \ V  V /|  __/| || (__| (_) || | | | | ||  __/ | |_| (_) | | |_ | | | ||  __/  |
|     \_/\_/  \___||_| \___|\___/ |_| |_| |_| \___|  \__|\___/   \__||_| |_| \___|  |
|   _____              _   ____                                                     |
|  |_   _|___    ___  | | | __ )   ___ __  __                                       |
|    | | / _ \  / _ \ | | |  _ \  / _ \\ \/ /                                       |
|    | || (_) || (_) || | | |_) || (_) |>  <                                        |
|    |_| \___/  \___/ |_| |____/  \___//_/\_\                                       |
+===================================================================================+
EOF

sleep 2

echo "Welcome to the Tool Box.
Here you can choose from a set of tools to learn how linux works."

sleep 1

echo "Please choose an option:"
echo "1) Update Tool"
echo "2) Command Learning"
echo "3) Back to Menu"

# Prompt for user input using the `read` command
read -p "Select an option (1, 2, 3, or 4): " option

# Based on the user choice, execute the corresponding installation
case $option in
    1)

    sleep 3 &
spinner
sleep 1

bash /$HOME/Downloads/linux-Playground/system-playground/update-tool.sh
    ;;

    2)

    sleep 3 &
spinner
sleep 1

bash /$HOME/Downloads/linux-Playground/system-playground/system_playground.sh

    ;;

    3)



    ;;

    4)



    ;;
esac

exit 1
