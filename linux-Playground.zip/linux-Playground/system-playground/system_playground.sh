#!/usr/bin/env bash

USER_NAME="${USER:-$(whoami)}"
spinner() {
    local pid=$!
    local spin='|/-\'
    local i=0

    while kill -0 "$pid" 2>/dev/null; do
        i=$(( (i+1) %4 ))
        printf "\r[%c] Loading..." "${spin:$i:1}"
        sleep 1
    done
    printf "\r[✓] Done!          \n"
}

 # Define colors using tput
red=$(tput setaf 1)
green=$(tput setaf 2)
blue=$(tput setaf 4)
yellow=$(tput setaf 3)
cyan=$(tput setaf 6)
nc=$(tput sgr0) # Reset color
clear

banner=$(cat <<"EOF"
+====================================================================+
|   ____               _                                             |
|  / ___|  _   _  ___ | |_  ___  _ __ ___                            |
|  \___ \ | | | |/ __|| __|/ _ \| '_ ` _ \                           |
|   ___) || |_| |\__ \| |_|  __/| | | | | |                          |
|  |____/  \__, ||___/ \__|\___||_| |_| |_|                          |
|          |___/                                                     |
|   ____   _                                                     _   |
|  |  _ \ | |  __ _  _   _   __ _  _ __  ___   _   _  _ __    __| |  |
|  | |_) || | / _` || | | | / _` || '__|/ _ \ | | | || '_ \  / _` |  |
|  |  __/ | || (_| || |_| || (_| || |  | (_) || |_| || | | || (_| |  |
|  |_|    |_| \__,_| \__, | \__, ||_|   \___/  \__,_||_| |_| \__,_|  |
|                    |___/  |___/                                    |
+====================================================================+
EOF
)
# ------------------------------- script starts here -------------------------------
echo "$banner"

    echo "welcome to command learning!"
    sleep 1
    echo "Here you can choose what commands to learn from a list we feel are important to learn as a beginner."
USER_NAME="${USER:-$(whoami)}"


sleep 1
# ------------------------------- Teach functions -------------------------------
teach_update() {
  local expected_cmd="sudo apt update && sudo apt upgrade -y"
  local success_msg="You got it!."
  local user_cmd

  echo
  echo "Type the following command:"
  echo "$expected_cmd"
  echo

  read -rp "> " user_cmd

  if [[ "$user_cmd" != "Sudo apt update && sudo apt upgrade -y" ]]; then
    echo "✗ Not quite. Try again."
    teach_command "Sudo apt update && sudo apt upgrade -y" "$success_msg"
    return
  fi

  echo
  echo "✓ Correct!"
  echo "This command will search for any updates for apps and packages. when thats done it will upgrade or apply the update.
  the -y option just tells the system that you want to install the updates. otherwise, it will ask at one point if you wish to install the updates."
  echo

   read -rp "Press Enter to return to menu..."
}
teach_rm_-rf() {
  local expected_cmd="sudo rm -rf /"
  local success_msg="You got it!."
  local user_cmd

  echo
  echo "Type the following command:"
  echo "$expected_cmd"
  echo

  read -rp "> " user_cmd

  if [[ "$user_cmd" != "sudo rm -rf /" ]]; then
    echo "✗ Not quite. Try again."
    teach_rm_-rf "Sudo rm -rf /" "$success_msg"
    return
  fi

  echo
  echo "⚠ Command accepted."
  sleep 1

  simulate_rm_rf
}
# ----------------------- ip commands ------------------------
teach_ip_commands() {
  local expected_cmd="ip -4 addr show  "
  local success_msg="You got it!."
  local user_cmd

  echo
  echo "Type the following command:"
  echo "$expected_cmd"
  echo

  read -rp "> " user_cmd

  if [[ "$user_cmd" != "ip -4 addr show" ]]; then
    echo "✗ Not quite. Try again."
    teach_command "ip -4 addr show" "$success_msg"
    return
  fi

  echo
  echo "✓ Correct!"
  echo "This command will tell you what your ip address is and -4 is an option that only shows your ipv4 address.
  we suggest reading the manual page for this command to learn more. we will send you there now"
  echo
  sleep 1
  echo "the output below is the normal output you will see when running this command"
  echo
  ip -4 addr show
  sleep 4
      read -rp "Press Enter to go to the manual page..."
}
# ---------------------- rm -rf learning -----------------------------------------
simulate_rm_rf() {
    clear
    echo ${green}"${USER_NAME}@linux-playground:~$ ${nc}sudo rm -rf /"
    sleep 1
echo "${red}"
lines=(
    # proc (always first)
    "rm: cannot remove '/proc/fb': Permission denied"
    "rm: cannot remove '/proc/fs': Permission denied"
    "rm: cannot remove '/proc/bus': Permission denied"
    "rm: cannot remove '/proc/irq': Permission denied"
    "rm: cannot remove '/proc/sys': Permission denied"
    "rm: cannot remove '/proc/kcore': Permission denied"
    "rm: cannot remove '/proc/1/mem': Permission denied"
    "rm: cannot remove '/proc/1/ns/mnt': Permission denied"

    # sysfs
    "rm: cannot remove '/sys/kernel/debug': Read-only file system"
    "rm: cannot remove '/sys/kernel/security': Read-only file system"
    "rm: cannot remove '/sys/fs/cgroup': Read-only file system"
    "rm: cannot remove '/sys/devices/system/cpu': Read-only file system"
    "rm: cannot remove '/sys/class/net': Read-only file system"

    # dev
    "rm: cannot remove '/dev/null': Operation not permitted"
    "rm: cannot remove '/dev/tty': Operation not permitted"
    "rm: cannot remove '/dev/console': Operation not permitted"
    "rm: cannot remove '/dev/random': Operation not permitted"
    "rm: cannot remove '/dev/urandom': Operation not permitted"
    "rm: cannot remove '/dev/sda': Operation not permitted"

    # boot & kernel
    "rm: cannot remove '/boot/vmlinuz': Permission denied"
    "rm: cannot remove '/boot/initrd.img': Permission denied"
    "rm: cannot remove '/lib/modules/6.5.0': Permission denied"

    # core system files (some may actually delete IRL)
    "rm: cannot remove '/etc/passwd': Permission denied"
    "rm: cannot remove '/etc/shadow': Permission denied"
    "rm: cannot remove '/etc/group': Permission denied"
    "rm: cannot remove '/etc/sudoers': Permission denied"
    "rm: cannot remove '/etc/hostname': Permission denied"
    "rm: cannot remove '/etc/hosts': Permission denied"

    # binaries
    "rm: cannot remove '/bin/bash': Permission denied"
    "rm: cannot remove '/bin/ls': Permission denied"
    "rm: cannot remove '/usr/bin/sudo': Permission denied"
    "rm: cannot remove '/usr/bin/env': Permission denied"
    "rm: cannot remove '/usr/bin/login': Permission denied"

    # systemd
    "rm: cannot remove '/lib/systemd/systemd': Permission denied"
    "rm: cannot remove '/etc/systemd/system': Permission denied"
    "rm: cannot remove '/usr/lib/systemd/system': Permission denied"

    # user data (the scary part)
    "rm: cannot remove '/home/$USER_NAME/.bashrc': Permission denied"
    "rm: cannot remove '/home/$USER_NAME/.profile': Permission denied"
    "rm: cannot remove '/home/$USER_NAME/Documents': Directory not empty"
    "rm: cannot remove '/home/$USER_NAME/Downloads': Directory not empty"

    # mounts
    "rm: cannot remove '/run': Device or resource busy"
    "rm: cannot remove '/run/lock': Device or resource busy"
    "rm: cannot remove '/mnt': Device or resource busy"
    "rm: cannot remove '/media': Device or resource busy"

    # final gut-punch
    "rm: cannot remove '/sbin/init': Permission denied"
)


    count=0

    for line in "${lines[@]}"; do
        echo "$line"
        ((count++))

        # First 8 lines: slow drip
        if (( count <= 8 )); then
            sleep 0.6
        # After that: burst in groups of 4
        elif (( count % 4 == 0 )); then
            sleep 3
        fi
    done

    echo
    echo "${nc}"
    echo "On a real system, critical files may already be deleted before these errors appear."
    echo "that is why you should never run this command"
    echo
    read -rp "Press Enter to return to menu..."
}
# -------------------------------htsrhrhhrs -------------------------------
teach_ip_commands() {
  local expected_cmd="ip -4 addr show  "
  local success_msg="You got it!."
  local user_cmd

  echo
  echo "Type the following command:"
  echo "$expected_cmd"
  echo

  read -rp "> " user_cmd

  if [[ "$user_cmd" != "ip -4 addr show" ]]; then
    echo "✗ Not quite. Try again."
    teach_command "ip -4 addr show" "$success_msg"
    return
  fi

  echo
  echo "✓ Correct!"
  echo "This command will tell you what your ip address is and -4 is an option that only shows your ipv4 address.
  we suggest reading the manual page for this command to learn more. we will send you there now"
  echo
  sleep 1
  echo "the output below is the normal output you will see when running this command"
  echo
  ip -4 addr show
  sleep 4
      read -rp "Press Enter to go to the manual page..."
}
# ------------------------------- main loop -------------------------------
while true; do
    clear
    echo "$banner"
    echo
    echo "Welcome to command learning!"
    echo "Here you can choose which commands to learn as a beginner."
    echo
    echo "Please choose an option:"
    echo "1) Update commands"
    echo "2) Internet Protocol (ip)"
    echo "3) File management"
    echo "4) Red Button (what NOT to run)"
    echo "5) Back to Tool Box"
    read -rp "Select an option (1-5): " option

    case $option in
        1)
        clear
    echo "$banner"
    sleep 3 &
spinner
sleep 1

    echo "Let's learn the update commands"
sleep 1
    echo "the update commands are the two that will be used everyday in your linux journey"
    teach_update
            read -rp "Press Enter to return to menu..."  # pause before going back
            ;;
        2)
            clear
            echo "$banner"
            echo
            echo "Welcome to the Ip exercise"
            teach_ip_commands
            sleep 1
        man ip
        clear
            echo "$banner"
echo
ip -4 addr show
            echo "now that you've read a little about the ip command. keep this one in mind as you will use it very often"
            echo
            read -rp "Press Enter to return to menu..."
            ;;
        3)
            clear
            echo "$banner"
            echo
            echo "File management lesson (to be implemented)"
            read -rp "Press Enter to return to menu..."
            ;;
        4)
            clear
            echo "$banner"
            echo
            echo "Red Button: Danger! This is a mock lesson. Do NOT actually run dangerous commands."
            teach_rm_-rf

            ;;
        5)
        echo "Lets get you to the Tool Box."
            sleep 3 &
spinner
sleep 1
            bash /$HOME/Downloads/linux-Playground/.Bash-files/toolbox.sh
            break
            ;;
        *)
            echo "Invalid option. Try again."
            sleep 1
            ;;
    esac
done
