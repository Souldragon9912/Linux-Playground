#!/usr/bin/env bash
set -e

clear

cat <<'EOF'
+==========================================+
|   _   _             _         _          |
|  | | | | _ __    __| |  __ _ | |_  ___   |
|  | | | || '_ \  / _` | / _` || __|/ _ \  |
|  | |_| || |_) || (_| || (_| || |_|  __/  |
|   \___/ | .__/  \__,_| \__,_| \__|\___|  |
|   _____ |_|          _                   |
|  |_   _|___    ___  | |                  |
|    | | / _ \  / _ \ | |                  |
|    | || (_) || (_) || |                  |
|    |_| \___/  \___/ |_|                  |
+==========================================+
EOF

LOGFILE="$HOME/system-update.log"

echo
echo "This tool will:
• Refresh package lists
• Install available updates"
echo



spinner() {
    local pid=$!
    local spin='|/-\'
    local i=0

    while kill -0 "$pid" 2>/dev/null; do
        i=$(( (i+1) %4 ))
        printf "\r[%c] Loading..." "${spin:$i:1}"
        sleep 1
    done
    printf "\r[✓] Done!          \n"
}

#install prompt
sleep 3 &
spinner
sleep 1

echo "Please choose an option:"
echo "1) Automatic (recommended)"
echo "2) Walk-through"
echo "3) Back to Menu"

# Prompt for user input using the `read` command
read -p "Select an option (1,2, or 3): " option


# Based on the user choice, execute the corresponding installation
case $option in
    1)

echo "Updating package lists..."
sleep 2
sudo apt update && sudo apt upgrade -y

shutdown -r 01:00
notify-send "System" "The system will restart to upgrade all packages at 1am"

sleep 3
exit 1
 ;;

 2)
 teach_command() {
  local expected_cmd="Sudo apt update && sudo apt upgrade -y"
  local success_msg="Alright, you got it boss. Lets edit that file."
  local user_cmd

  echo
  echo "Type the following command:"
  echo "$expected_cmd"
  echo

  read -rp "> " user_cmd

  if [[ "$user_cmd" != "sudo apt update && sudo apt upgrade -y" ]]; then
    echo "✗ Not quite. Try again."
    teach_command "Sudo apt update && sudo apt upgrade -y" "$success_msg"
    return
  fi

  echo
  echo "✓ Correct!"
  echo "This command will search for any updates for apps and packages. when thats done it will upgrade or apply the update. the -y option just tells the system that you want to install the updates"
  echo

  sleep 10


}

teach_command

  sudo apt-get update && sudo apt-get upgrade -y

sleep 2

shutdown -r 01:00
notify-send "System" "The system will restart to upgrade all packages at 1am"

  ;;

  3)

  echo "returning to menu..."
  sleep 3

  bash /$HOME/Downloads/bash_tools/toolbox.sh

  ;;
esac


sleep 3
clear

